import java.util.*;


public class leetcode {

    public static void main(String[] args) {





    }

    public void dfs(int[] preorder, int[] inorder,TreeNode node){
        if(node.left == null && node.right == null){
            return;
        }


        for(int j=0;j<inorder.length;j++){
            int[] leftArr = new int[j];
            for(int k=0;k<leftArr.length;k++){
                leftArr[k] = inorder[k];
            }

            int[] rightArr = new int[inorder.length-j - 1];
            for(int m=0;m<rightArr.length;m++){
                rightArr[m] = inorder[inorder.length - rightArr.length  + m];
            }


        }

    }




}



