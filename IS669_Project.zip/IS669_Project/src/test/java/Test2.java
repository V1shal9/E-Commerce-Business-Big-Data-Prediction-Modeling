import org.datanucleus.store.query.AbstractQueryResult;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class Test2 {

    public static void main(String[] args) {
        int[] preorder = new int[4];
        int[] inorder = new int[4];



        dfs(preorder, 0, preorder.length-1, inorder, 0, inorder.length-1);

    }

    public static TreeNode dfs(int[] preorder, int prestart, int preend, int[] inorder, int instart, int inend){
        if(prestart > preend || instart > inend){
            return null;
        }

        TreeNode node = new TreeNode(preorder[prestart]);

        int k=0;
        for(int i=0;i<inorder.length;i++){
            if(inorder[i] == node.val){
                k = i;
                break;
            }
        }



        node.left = dfs(preorder,prestart+1,prestart+(k-instart),inorder,instart,k-1);
        node.right = dfs(preorder,prestart+(k-instart)+1,preorder.length - 1,inorder,k+1,inend);

        node.left = dfs(preorder, prestart+1, prestart+(k-instart), inorder, instart, k-1);
        node.right= dfs(preorder, prestart+(k-instart)+1, preend, inorder, k+1 , inend);

        return node;
    }


}

class TreeNode {
     int val;
     TreeNode left;
      TreeNode right;
    TreeNode(int x) { val = x; }
  }