package jdbc;


import dao.*;
import impl.*;

/**
 * DAO工厂类
 * @author Administrator
 *
 */
public class DAOFactory {

	/**
	 * 获取任务管理DAO
	 * @return DAO
	 */
	public static TaskDAOImpl getTaskDAO() {
		return new TaskDAOImpl();
	}

	/**
	 * 获取session聚合DAO
	 * @return
	 */
	public static SessionExtractRandomDAO getSessionExtractRandomDAO(){
		return new SessionExtractRandomDAOImpl();
	}

	public static SessionDetailDAOImpl getSessionDetailDAO(){
		return new SessionDetailDAOImpl();
	}

	public static SessionAggrDAO getSessionAggrDAO(){
		return new SessionAggrDAOmpl();
	}

	public static Top10CategoryDAO getTop10CategoryDAO(){
		return new Top10CategoryDAOImpl();
	}




}
