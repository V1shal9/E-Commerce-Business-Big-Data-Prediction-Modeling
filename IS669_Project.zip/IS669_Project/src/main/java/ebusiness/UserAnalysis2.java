package ebusiness;

import com.alibaba.fastjson.JSONObject;
import conf.ConfigurationManager;
import constant.Constant;
import dao.ITaskDAO;
import dao.SessionExtractRandomDAO;
import dao.Top10CategoryDAO;
import domain.*;
import impl.SessionDetailDAOImpl;
import jdbc.DAOFactory;
import org.apache.spark.SparkContext;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.*;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.hive.HiveContext;
import scala.Tuple2;
import sortKey.CategorySortKey;
import utils.DateUtils;
import utils.ParamUtils;
import utils.StringUtils;
import utils.ValidUtils;

import java.util.*;

public class UserAnalysis2 {
    public static void main(String[] args) {
        SparkSession spark = SparkSession.builder().appName("UserAnalysis2").master("local").getOrCreate();


        JavaRDD<Row> actionRDD = spark.read().parquet("D:\\logs\\input\\ebusiness2").javaRDD();
        JavaRDD<Row> userActionRDD = spark.read().parquet("D:\\logs\\input\\user_info").javaRDD();


        ITaskDAO taskDAO = DAOFactory.getTaskDAO();
        long taskId = ParamUtils.getTaskIdFromArgs(args, Constant.SPARK_LOCAL_TASKID_SESSION);
        System.out.println("taskId:"+taskId);
        Task task = taskDAO.findById(taskId);
        if(task == null){
            System.out.println(new Date()+"cannot find this task with id ["+taskId+ "].");
            return;
        }

        JSONObject taskParam = JSONObject.parseObject(task.getTaskParam());


        JavaPairRDD<String, Row> sessionId2ActionRdd = getSessionId2ActionRDD(actionRDD);

        JavaPairRDD<String, String> sessionId2FullAggrInfoRdd = getSessionId2FullAggrInfoRdd(userActionRDD,sessionId2ActionRdd);



//        JavaPairRDD<String, String> filteredAggrRDD = filterSessionAndAggr(taskParam,  sessionId2FullAggrInfoRdd);


        JavaPairRDD<String, Row> sessionid2detailRDD = getSessionid2detailRDD(sessionId2FullAggrInfoRdd, sessionId2ActionRdd);


        getRandomExtractDetailRDD(taskId,sessionid2detailRDD,sessionId2FullAggrInfoRdd);


        List<Tuple2<CategorySortKey, String>> top10CategoryList = getTop10Category(taskId, sessionid2detailRDD);






    }



    private static SQLContext getSqlContext(SparkContext sc){
        boolean local = ConfigurationManager.getBoolean(Constant.SPARK_LOCAL);
        if(local){
            return new SQLContext(sc);
        }else{
            return new HiveContext(sc);
        }
    }

    private static JavaRDD<Row> getActionRDDByDateRange(SQLContext sqlContext, JSONObject taskParam){
        String startDate = ParamUtils.getParam(taskParam, Constant.PARAM_START_DATE);
        String endDate = ParamUtils.getParam(taskParam, Constant.PARAM_END_DATE);
        String sql =
                "select * "
                        + "from user_visit_action "
                        + "where day>='" + startDate + "' "
                        + "and day<='" + endDate + "'";
        JavaRDD<Row> javaRDD = sqlContext.sql(sql).javaRDD();
        return javaRDD;
    }

    private static JavaPairRDD<String, Row> getSessionId2ActionRDD(JavaRDD<Row> actionRDD) {
        JavaPairRDD<String, Row> sessionId2ActionRDD = actionRDD.mapToPair(new PairFunction<Row, String, Row>() {
            @Override
            public Tuple2<String, Row> call(Row row) throws Exception {
                return new Tuple2<>(row.getString(2), row);
            }
        });
        return sessionId2ActionRDD;
    }


    private static JavaPairRDD<String, String> getSessionId2FullAggrInfoRdd(JavaRDD<Row> userActionRDD , JavaPairRDD<String, Row> sessionId2ActionRDD){
        JavaPairRDD<String, Iterable<Row>> sessionId2IterRow = sessionId2ActionRDD.groupByKey();

        JavaPairRDD<Long, String> userId2PartInfoRDD = sessionId2IterRow.mapToPair(new PairFunction<Tuple2<String, Iterable<Row>>, Long, String>() {
            @Override
            public Tuple2<Long, String> call(Tuple2<String, Iterable<Row>> tp) throws Exception {
                Iterator<Row> iterator = tp._2.iterator();

                StringBuffer searchKeywordBuffer = new StringBuffer();
                StringBuffer categoryIdBuffer = new StringBuffer();

                String sessionId = tp._1;
                Long userId = 0L;

                Date startTime = null;
                Date endTime = null;

                long stepLength = 0L;

                while (iterator.hasNext()) {
                    Row row = iterator.next();
                    Date actionTime = DateUtils.parseTime(row.getString(4));

                    if (userId == null) {
                        userId = row.getLong(1);
                    }
                    String searchKeyWord = row.getString(5);
                    Long clickCategoryId = row.getLong(6);

                    if(startTime == null){
                        startTime = actionTime;
                    }
                    if(endTime == null){
                        endTime = actionTime;
                    }

                    if(actionTime.before(startTime)){
                        startTime = actionTime;
                    }

                    if(actionTime.after(endTime)){
                        endTime = actionTime;
                    }




                    if (StringUtils.isNotEmpty(searchKeyWord)) {
                        if (!searchKeywordBuffer.toString().trim().contains(searchKeyWord)) {
                            searchKeywordBuffer.append(searchKeyWord + ",");
                        }
                    }

                    if (clickCategoryId != null) {
                        if (!categoryIdBuffer.toString().trim().contains(String.valueOf(clickCategoryId))) {
                            categoryIdBuffer.append(clickCategoryId+",");
                        }
                    }
                    stepLength++;
                }




                long visitLength = (endTime.getTime() - startTime.getTime()) / 1000;
                String searchKeyWords = searchKeywordBuffer.toString();
                searchKeyWords = StringUtils.trimComma(searchKeyWords);

                String categoryIds = categoryIdBuffer.toString();
                categoryIds = StringUtils.trimComma(categoryIds);

                String partInfo = Constant.FIELD_SESSION_ID + "=" + sessionId + "|" +
                        Constant.FIELD_SEARCH_KEYWORDS + "=" + searchKeyWords + "|" +
                        Constant.FIELD_CLICK_CATEGORY + "=" + categoryIds + "|" +
                        Constant.FIELD_VISIT_LENGTH+"="+visitLength+"|" +
                        Constant.FIELD_STEP_LENGTH+"="+stepLength+"|"+
                        Constant.FIELD_START_TIME+"="+ DateUtils.formatTime(startTime);

                return new Tuple2<>(userId, partInfo);
            }
        });



        JavaPairRDD<Long, Row> userId2UserInfoRDD = userActionRDD .mapToPair(new PairFunction<Row, Long, Row>() {
            @Override
            public Tuple2<Long, Row> call(Row row) throws Exception {
                return new Tuple2<>(row.getLong(0), row);
            }
        });

        JavaPairRDD<String, String> sessionId2FullAggrInfoRdd = userId2PartInfoRDD.join(userId2UserInfoRDD).mapToPair(new PairFunction<Tuple2<Long, Tuple2<String, Row>>, String, String>() {
            @Override
            public Tuple2<String, String> call(Tuple2<Long, Tuple2<String, Row>> tp) throws Exception {

                String partInfo = tp._2._1;

                Row row = tp._2._2;
                //String sessionId = row.getString(2);
                int age = row.getInt(3);
                String professional = row.getString(4);
                String city = row.getString(5);
                String sex = row.getString(6);

                String fullInfo = partInfo + "|" + Constant.FIELD_AGE + "=" + age
                        + "|" + Constant.FIELD_PROFESSIONAL + "=" + professional
                        + "|" + Constant.FIELD_CITY + "=" + city
                        + "|" + Constant.FIELD_SEX + "=" + sex;
               String sessionId = StringUtils.getFieldFromConcatString(fullInfo, "\\|", Constant.FIELD_SESSION_ID);
                return new Tuple2<>(sessionId, fullInfo);
            }
        });
        return sessionId2FullAggrInfoRdd;

    }

    private static JavaPairRDD<String, String> filterSessionAndAggr(final JSONObject taskParm, JavaPairRDD<String, String> sessionId2FullAggrInfoRdd
    ){


        String startAge = ParamUtils.getParam(taskParm, Constant.PARAM_START_AGE);
        String endAge = ParamUtils.getParam(taskParm, Constant.PARAM_END_AGE);
        String professionals = ParamUtils.getParam(taskParm, Constant.PARAM_PROFESSIONALS);
        String cities = ParamUtils.getParam(taskParm, Constant.PARAM_CITIES);
        String sex = ParamUtils.getParam(taskParm, Constant.PARAM_SEX);
        String keywords = ParamUtils.getParam(taskParm, Constant.PARAM_KEYWORDS);
        String categoryIds = ParamUtils.getParam(taskParm, Constant.PARAM_CATEGORY_IDS);

        String _parameter = (startAge != null? Constant.PARAM_START_AGE+"="+startAge+"|":"")+(endAge != null? Constant.PARAM_END_AGE+"="+endAge+"|":"")+
                (professionals != null? Constant.PARAM_PROFESSIONALS+"="+professionals+"|":"")+(cities != null? Constant.PARAM_CITIES+"="+cities+"|":"")+
                (sex != null? Constant.PARAM_SEX+"="+sex+"|":"")+(keywords != null? Constant.PARAM_KEYWORDS+"="+keywords+"|":"")+
                (categoryIds != null? Constant.PARAM_CATEGORY_IDS+"="+categoryIds+"|":"");

        if(_parameter.endsWith("\\|")){
            _parameter = _parameter.substring(0, _parameter.length()-1);
        }

        final String parameter = _parameter;

        JavaPairRDD<String, String> filteredRDD = sessionId2FullAggrInfoRdd.filter(new Function<Tuple2<String, String>, Boolean>() {
            @Override
            public Boolean call(Tuple2<String, String> tp) throws Exception {
                String aggrInfo = tp._2;
                //接着，依次按照筛选条件进行过滤
                //按照年龄范围进行过滤(startAge,endAge)
                if (!ValidUtils.between(aggrInfo, Constant.FIELD_AGE, parameter, Constant.PARAM_START_AGE, Constant.PARAM_END_AGE)) {
                    return false;
                }

                //按照职业范围进行过滤
                //互联网，IT，软件
                if (!ValidUtils.in(aggrInfo, Constant.FIELD_PROFESSIONAL, parameter, Constant.PARAM_PROFESSIONALS)) {
                    return false;
                }

                //按照城市范围进行过滤
                //北京，上海，深圳，广州
                //成都
                if (!ValidUtils.in(aggrInfo, Constant.FIELD_CITY, parameter, Constant.PARAM_CITIES)) {
                    return false;
                }

                //按照性别进行过滤
                //男，女
                //男
                if (!ValidUtils.equal(aggrInfo, Constant.FIELD_SEX, parameter, Constant.PARAM_SEX)) {
                    return false;
                }

                if (!ValidUtils.in(aggrInfo, Constant.FIELD_SEARCH_KEYWORDS, parameter, Constant.PARAM_KEYWORDS)) {
                    return false;
                }

                //按照点击品类进行分类
                if (!ValidUtils.in(aggrInfo, Constant.FIELD_CLICK_CATEGORY, parameter, Constant.PARAM_CATEGORY_IDS)) {
                    return false;
                }


                return true;
            }

        });


        return filteredRDD;

    }

    private static JavaPairRDD<String, Row> getSessionid2detailRDD(JavaPairRDD<String, String> filterSessionIdAggrInfoRdd, JavaPairRDD<String, Row> sessionId2ActionRDD){
        JavaPairRDD<String, Row> sessionId2DetailRDD = filterSessionIdAggrInfoRdd.join(sessionId2ActionRDD).mapToPair(new PairFunction<Tuple2<String, Tuple2<String, Row>>, String, Row>() {
            private static final long serialVersionUID = 1L;

            @Override
            public Tuple2<String, Row> call(Tuple2<String, Tuple2<String, Row>> tp) throws Exception {
                return new Tuple2<>(tp._1, tp._2._2);
            }
        });
        return sessionId2DetailRDD;
    }

    private static void getRandomExtractDetailRDD(final long taskId, JavaPairRDD<String, Row> sessionId2DetailRDD, JavaPairRDD<String, String> filteredAggrRDD){



            JavaPairRDD<String, String> dateHour2AggrInfoRDD = filteredAggrRDD.mapToPair(new PairFunction<Tuple2<String, String>, String, String>() {
                @Override
                public Tuple2<String, String> call(Tuple2<String, String> tp) throws Exception {
                    String aggrInfo = tp._2;

                    String startTime = StringUtils.getFieldFromConcatString(aggrInfo, "\\|", Constant.FIELD_START_TIME);

                    String dateHour = DateUtils.getDateHour(startTime);
                    return new Tuple2<>(dateHour, aggrInfo);
                }
            });

            Map<String, Long> aggrInfoCountMap = dateHour2AggrInfoRDD.countByKey();

            Map<String,Map<String,Long>> dayAndHourCountMap = new HashMap<>();

            Random random = new Random();

            for(Map.Entry<String,Long> aggrInfoCountEntry:aggrInfoCountMap.entrySet()){
                String dateHour = aggrInfoCountEntry.getKey();
                String day = dateHour.split("_")[0];
                String hour = dateHour.split("_")[1];

                Long count = Long.valueOf(String.valueOf(aggrInfoCountEntry.getValue()));
                Map<String, Long> hourCountMap = dayAndHourCountMap.get(day);
                if(hourCountMap == null){
                    hourCountMap = new HashMap<>();
                    dayAndHourCountMap.put(day, hourCountMap);

                }
                hourCountMap.put(hour,count);
            }

            int extractPerDayNum = 100 / dayAndHourCountMap.size();

            final Map<String,Map<String,List<Integer>>> extractCountMap = new HashMap<>();

            for(Map.Entry<String,Map<String,Long>> dayAndHourCountEntry:dayAndHourCountMap.entrySet()){
                String day = dayAndHourCountEntry.getKey();
                Map<String, Long> hourCountMap = dayAndHourCountEntry.getValue();

                long totalCount = 0L;
                for(Long count:hourCountMap.values()){
                    totalCount += count;
                }

                Map<String, List<Integer>> extractHourMap = extractCountMap.get(day);
                if(extractHourMap == null){
                    extractHourMap = new HashMap<>();
                    extractCountMap.put(day, extractHourMap);
                }

                for(Map.Entry<String,Long> hourCountEntry:hourCountMap.entrySet()){
                    String hour = hourCountEntry.getKey();
                    long hourCount = hourCountEntry.getValue();

                    int extractPerHourNum = (int)((hourCount*1.0) / (totalCount*1.0) * extractPerDayNum);
                    if(extractPerHourNum > hourCount){
                        extractPerHourNum = (int)hourCount;
                    }

                    List<Integer> extractList = extractHourMap.get(hour);
                    if(extractList == null){
                        extractList = new ArrayList<>();
                        extractHourMap.put(hour,extractList);
                    }
                    for(int i=0;i<extractPerHourNum;i++){
                        int index = random.nextInt((int)hourCount);
                        while(extractList.contains(index)){
                            index = random.nextInt((int)hourCount);
                        }
                        extractList.add(index);
                    }

                }
            }

        JavaPairRDD<String, Iterable<String>> dateHour2AggrInfoIterRDD = dateHour2AggrInfoRDD.groupByKey();

        JavaPairRDD<String, String> extractSessionIdsRDD = dateHour2AggrInfoIterRDD.flatMapToPair(new PairFlatMapFunction<Tuple2<String, Iterable<String>>, String, String>() {
            @Override
            public Iterator<Tuple2<String, String>> call(Tuple2<String, Iterable<String>> tp) throws Exception {
                String dateHour = tp._1;

                String date = dateHour.split("_")[0];
                String hour = dateHour.split("_")[1];

                List<Integer> extractList = extractCountMap.get(date).get(hour);

                List<Tuple2<String, String>> sessionId2SessionId = new ArrayList<>();

                Iterator<String> iterator = tp._2.iterator();
                int index = 0;
                SessionExtractRandomDAO sessionExtractRandomDAO = DAOFactory.getSessionExtractRandomDAO();
                while (iterator.hasNext()) {
                    String fullInfo = iterator.next();
                    String startTime = StringUtils.getFieldFromConcatString(fullInfo, "\\|", Constant.FIELD_START_TIME);
                    String sessionId = StringUtils.getFieldFromConcatString(fullInfo, "\\|", Constant.FIELD_SESSION_ID);
                    String searchKeywords = StringUtils.getFieldFromConcatString(fullInfo, "\\|", Constant.FIELD_SEARCH_KEYWORDS);
                    String categoryIds = StringUtils.getFieldFromConcatString(fullInfo, "\\|", Constant.FIELD_CLICK_CATEGORY);

                    if (extractList.contains(index)) {
                        SessionRandomExtract sessionRandomExtract = new SessionRandomExtract();
                        sessionRandomExtract.setTaskId(taskId);
                        sessionRandomExtract.setSessionId(sessionId);
                        sessionRandomExtract.setStartTime(startTime);
                        sessionRandomExtract.setSearchKeywords(searchKeywords);
                        sessionRandomExtract.setClickCategoryIds(categoryIds);

                        sessionExtractRandomDAO.insert(sessionRandomExtract);
                        sessionId2SessionId.add(new Tuple2<>(sessionId, sessionId));
                    }
                    index++;

                }
                return sessionId2SessionId.iterator();

            }
        });

        extractSessionIdsRDD.join(sessionId2DetailRDD).foreachPartition(new VoidFunction<Iterator<Tuple2<String, Tuple2<String, Row>>>>() {
            @Override
            public void call(Iterator<Tuple2<String, Tuple2<String, Row>>> iterator) throws Exception {
                SessionDetailDAOImpl sessionDetailDAO = DAOFactory.getSessionDetailDAO();
                while(iterator.hasNext()){
                    Row row = iterator.next()._2._2;
                    SessionDetail sessionDetail = new SessionDetail();
                    sessionDetail.setTaskid(taskId);
                    sessionDetail.setUserid(row.getLong(1));
                    sessionDetail.setSessionid(row.getString(2));
                    sessionDetail.setPageid(row.getLong(3));
                    sessionDetail.setActionTime(row.getString(4));
                    sessionDetail.setSearchKeyword(row.getString(5));
                    sessionDetail.setClickCategoryId(row.getLong(6));
                    sessionDetail.setClickProductId(row.getLong(7));
                    sessionDetail.setOrderCategoryIds(row.getString(8));
                    sessionDetail.setOrderProductIds(row.getString(9));
                    sessionDetail.setPayCategoryIds(row.getString(10));
                    sessionDetail.setPayProductIds(row.getString(11));

                    sessionDetailDAO.insert(sessionDetail);
                }
            }
        });
    }



    private static List<Tuple2<CategorySortKey, String>> getTop10Category(long taskId, JavaPairRDD<String, Row> sessionid2detailRDD){
        JavaPairRDD<Long, Long> categoryIdsRDD = sessionid2detailRDD.flatMapToPair(new PairFlatMapFunction<Tuple2<String, Row>, Long, Long>() {
            @Override
            public Iterator<Tuple2<Long, Long>> call(Tuple2<String, Row> tp) throws Exception {
                List<Tuple2<Long, Long>> categoryIdList = new ArrayList<>();
                String sessionId = tp._1;

                Row row = tp._2;
                Long clickCategoryId = row.getLong(6);
                if (!"null".equals(clickCategoryId)) {
                    categoryIdList.add(new Tuple2<>(clickCategoryId, clickCategoryId));
                }

                String orderCategoryId = row.getString(8);
                if(!"null".equals(orderCategoryId)) {
                    categoryIdList.add(new Tuple2<>(Long.valueOf(orderCategoryId), Long.valueOf(orderCategoryId)));
                }

                String payCategoryId = row.getString(10);
                if (!"null".equals(payCategoryId)) {

                    categoryIdList.add(new Tuple2<>(Long.valueOf(payCategoryId), Long.valueOf(payCategoryId)));

                }
                return categoryIdList.iterator();
            }
        });

        JavaPairRDD<Long, Long> distinctCategoryIdsRDD = categoryIdsRDD.distinct();

        JavaPairRDD<Long, Long> clickCategoryId2CountRDD = getClickCategoryId2CountRDD(sessionid2detailRDD);
        JavaPairRDD<Long, Long> orderCategoryId2CountRDD = getOrderCategoryId2CountRDD(sessionid2detailRDD);
        JavaPairRDD<Long, Long> payCategoryId2CountRDD = getPayCategoryId2CountRDD(sessionid2detailRDD);

        JavaPairRDD<CategorySortKey, String> finalJoinRDD = joinCategoryAndData(distinctCategoryIdsRDD, clickCategoryId2CountRDD, orderCategoryId2CountRDD, payCategoryId2CountRDD);

        JavaPairRDD<CategorySortKey, String> sortedCategoryCountRDD = finalJoinRDD.sortByKey(false);

        List<Tuple2<CategorySortKey, String>> categoryCountList = sortedCategoryCountRDD.take(10);

        Top10CategoryDAO top10CategoryDAO = DAOFactory.getTop10CategoryDAO();
        for(Tuple2<CategorySortKey, String> categoryCountTp:categoryCountList){


            String value = categoryCountTp._2;

            long categoryId = Long.valueOf(StringUtils.getFieldFromConcatString(value, "\\|", Constant.FIELD_CATEGORY_ID));
            long clickCount = Long.valueOf(StringUtils.getFieldFromConcatString(value, "\\|", Constant.FIELD_CLICK_COUNT));
            long orderCount = Long.valueOf(StringUtils.getFieldFromConcatString(value, "\\|", Constant.FIELD_ORDER_COUNT));
            long payCount = Long.valueOf(StringUtils.getFieldFromConcatString(value, "\\|", Constant.FIELD_PAY_COUNT));

            Top10Category top10Category = new Top10Category();
            top10Category.setTaskId(taskId);
            top10Category.setCategoryId(categoryId);
            top10Category.setClickCount(clickCount);
            top10Category.setOrderCount(orderCount);
            top10Category.setPayCount(payCount);

            top10CategoryDAO.insert(top10Category);
        }

        return categoryCountList;
    }

    private static JavaPairRDD<Long, Long> getClickCategoryId2CountRDD(JavaPairRDD<String, Row> sessionid2detailRDD){

        JavaPairRDD<String, Row> clickActionRDD = sessionid2detailRDD.filter(new Function<Tuple2<String, Row>, Boolean>() {
            @Override
            public Boolean call(Tuple2<String, Row> tp) throws Exception {
                Row row = tp._2;
                return row.getLong(6) != 0L ? true : false;

            }
        });


        JavaPairRDD<Long, Long> clickCategoryIdAndOne = clickActionRDD.mapToPair(new PairFunction<Tuple2<String, Row>, Long, Long>() {
            @Override
            public Tuple2<Long, Long> call(Tuple2<String, Row> tp) throws Exception {
                Row row = tp._2;
                return new Tuple2<>(row.getLong(6), 1L);
            }
        });

        JavaPairRDD<Long, Long> reducedRDD = clickCategoryIdAndOne.reduceByKey(new Function2<Long, Long, Long>() {
            @Override
            public Long call(Long v1, Long v2) throws Exception {
                return v1 + v2;
            }
        });

        return reducedRDD;
    }

    private static JavaPairRDD<Long, Long> getOrderCategoryId2CountRDD(JavaPairRDD<String, Row> sessionid2detailRDD){

        JavaPairRDD<String, Row> orderActionRDD = sessionid2detailRDD.filter(new Function<Tuple2<String, Row>, Boolean>() {
            @Override
            public Boolean call(Tuple2<String, Row> tp) throws Exception {
                Row row = tp._2;

                return (!"null".equals(row.getString(8))) ? true : false;

            }
        });


        JavaPairRDD<Long, Long> orderCategoryIdAndOne = orderActionRDD.mapToPair(new PairFunction<Tuple2<String, Row>, Long, Long>() {
            @Override
            public Tuple2<Long, Long> call(Tuple2<String, Row> tp) throws Exception {
                Row row = tp._2;
                String orderCategoryId = row.getString(8);
                return new Tuple2<>(Long.valueOf(orderCategoryId), 1L);
            }
        });


        JavaPairRDD<Long, Long> reducedRDD = orderCategoryIdAndOne.reduceByKey(new Function2<Long, Long, Long>() {
            @Override
            public Long call(Long v1, Long v2) throws Exception {
                return v1 + v2;
            }
        });

        return reducedRDD;
    }

    private static JavaPairRDD<Long, Long> getPayCategoryId2CountRDD(JavaPairRDD<String, Row> sessionid2detailRDD){

        JavaPairRDD<String, Row> payActionRDD = sessionid2detailRDD.filter(new Function<Tuple2<String, Row>, Boolean>() {
            @Override
            public Boolean call(Tuple2<String, Row> tp) throws Exception {
                Row row = tp._2;
                return (!"null".equals(row.getString(10))) ? true : false;

            }
        });


        JavaPairRDD<Long, Long> payCategoryIdAndOne = payActionRDD.mapToPair(new PairFunction<Tuple2<String, Row>, Long, Long>() {
            @Override
            public Tuple2<Long, Long> call(Tuple2<String, Row> tp) throws Exception {
                Row row = tp._2;
                String payCategoryId = row.getString(10);

                return new Tuple2<>(Long.valueOf(payCategoryId), 1L);
            }
        });



        JavaPairRDD<Long, Long> reducedRDD = payCategoryIdAndOne.reduceByKey(new Function2<Long, Long, Long>() {
            @Override
            public Long call(Long v1, Long v2) throws Exception {
                return v1 + v2;
            }
        });

        return reducedRDD;
    }

    private static JavaPairRDD<CategorySortKey, String> joinCategoryAndData(JavaPairRDD<Long, Long> distinctCategoryIdsRDD, JavaPairRDD<Long, Long> clickCategoryId2CountRDD
    , JavaPairRDD<Long, Long> orderCategoryId2CountRDD, JavaPairRDD<Long, Long> payCategoryId2CountRDD){

        JavaPairRDD<Long, String> tmpJoinRDD = distinctCategoryIdsRDD.leftOuterJoin(clickCategoryId2CountRDD).mapToPair(new PairFunction<Tuple2<Long, Tuple2<Long, org.apache.spark.api.java.Optional<Long>>>, Long, String>() {
            @Override
            public Tuple2<Long, String> call(Tuple2<Long, Tuple2<Long, org.apache.spark.api.java.Optional<Long>>> tp) throws Exception {
                Long clickCategoryId = tp._2._1;
                long clickCount = 0L;
                org.apache.spark.api.java.Optional<Long> optional = tp._2._2;
                if (optional.isPresent()) {
                    clickCount = optional.get();
                }
                String value = Constant.FIELD_CATEGORY_ID + "=" + clickCategoryId + "|" + Constant.FIELD_CLICK_COUNT + "=" + clickCount;
                return new Tuple2<>(clickCategoryId, value);
            }
        });

        tmpJoinRDD = tmpJoinRDD.leftOuterJoin(orderCategoryId2CountRDD).mapToPair(new PairFunction<Tuple2<Long, Tuple2<String, org.apache.spark.api.java.Optional<Long>>>, Long, String>() {
            @Override
            public Tuple2<Long, String> call(Tuple2<Long, Tuple2<String, org.apache.spark.api.java.Optional<Long>>> tp) throws Exception {
                long categoryId = tp._1;
                String value = tp._2._1;
                org.apache.spark.api.java.Optional<Long> optional = tp._2._2;
                long orderCount = 0L;
                if(optional.isPresent()){
                    orderCount  = optional.get();

                }
                value = value + "|"+ Constant.FIELD_ORDER_COUNT +"="+orderCount;
                return new Tuple2<>(categoryId,value);
            }
        });

        tmpJoinRDD = tmpJoinRDD.leftOuterJoin(payCategoryId2CountRDD).mapToPair(new PairFunction<Tuple2<Long, Tuple2<String, org.apache.spark.api.java.Optional<Long>>>, Long, String>() {
            @Override
            public Tuple2<Long, String> call(Tuple2<Long, Tuple2<String, org.apache.spark.api.java.Optional<Long>>> tp) throws Exception {
                long categoryId = tp._1;
                String value = tp._2._1;
                org.apache.spark.api.java.Optional<Long> optional = tp._2._2;
                long payCount = 0L;
                if(optional.isPresent()){
                    payCount  = optional.get();

                }
                value = value + "|"+ Constant.FIELD_PAY_COUNT +"="+payCount;
                return new Tuple2<>(categoryId,value);
            }
        });

        JavaPairRDD<CategorySortKey, String> finalJoinRDD = tmpJoinRDD.mapToPair(new PairFunction<Tuple2<Long, String>, CategorySortKey, String>() {
            @Override
            public Tuple2<CategorySortKey, String> call(Tuple2<Long, String> tp) throws Exception {

                String value = tp._2;
                long clickCount = Long.valueOf(StringUtils.getFieldFromConcatString(value, "\\|", Constant.FIELD_CLICK_COUNT));
                long orderCount = Long.valueOf(StringUtils.getFieldFromConcatString(value, "\\|", Constant.FIELD_ORDER_COUNT));
                long payCount = Long.valueOf(StringUtils.getFieldFromConcatString(value, "\\|", Constant.FIELD_PAY_COUNT));

                CategorySortKey categorySortKey = new CategorySortKey(clickCount, orderCount, payCount);
                return new Tuple2<>(categorySortKey, value);
            }
        });

        return finalJoinRDD;
    }



}
