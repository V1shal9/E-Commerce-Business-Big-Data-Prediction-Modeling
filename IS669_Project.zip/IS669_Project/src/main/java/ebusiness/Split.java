package ebusiness;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFunction;
import scala.Char;
import scala.Tuple2;

import java.util.*;

public class Split {
    public static void main (String[] args) {
        int[] nums = new int[2];



        int[][] res = new int[2][2];

        System.out.println(res[0][0]);
    }
}
