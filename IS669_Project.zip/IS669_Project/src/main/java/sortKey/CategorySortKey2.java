package sortKey;

import scala.math.Ordered;

import java.util.Objects;

public class CategorySortKey2 implements Ordered<CategorySortKey2> {
    private long clickCount;
    private long orderCount;
    private long payCount;

    public long getClickCount() {
        return clickCount;
    }

    public void setClickCount(long clickCount) {
        this.clickCount = clickCount;
    }

    public long getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(long orderCount) {
        this.orderCount = orderCount;
    }

    public long getPayCount() {
        return payCount;
    }

    public void setPayCount(long payCount) {
        this.payCount = payCount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CategorySortKey2)) return false;
        CategorySortKey2 that = (CategorySortKey2) o;
        return getClickCount() == that.getClickCount() &&
                getOrderCount() == that.getOrderCount() &&
                getPayCount() == that.getPayCount();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getClickCount(), getOrderCount(), getPayCount());
    }

    @Override
    public int compare( CategorySortKey2 that) {
        if(this.clickCount - that.getClickCount() != 0){
            return (int)(this.clickCount - that.getClickCount());
        }else if(this.orderCount - that.getOrderCount() != 0){
            return (int)(this.orderCount - that.getOrderCount());
        }else if(this.payCount - that.getPayCount() != 0){
            return (int)(this.payCount - that.getPayCount());
        }else{
            return 0;
        }
    }

    @Override
    public boolean $less(CategorySortKey2 that) {
        if(this.clickCount - that.getClickCount() < 0){
            return true;
        }else if(this.clickCount == that.getClickCount() && this.orderCount < that.getOrderCount()){
            return true;
        }else if(this.clickCount == that.getClickCount() && this.orderCount == that.getOrderCount() && this.payCount < that.getPayCount()){
            return true;
        }else{
            return false;
        }

    }

    @Override
    public boolean $greater( CategorySortKey2 that) {
        if(this.clickCount > that.getClickCount()){
            return true;
        }else if(this.clickCount == that.getClickCount() && this.orderCount > that.getOrderCount()){
            return true;
        }else if(this.clickCount == that.getClickCount() && this.orderCount == that.getOrderCount() && this.payCount > that.getPayCount()){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public boolean $less$eq( CategorySortKey2 that) {
        if(this.$less(that)){
            return true;
        }else if(this.clickCount == that.getClickCount() && this.orderCount == that.getOrderCount() && this.payCount == that.getPayCount()){
            return true;
        }else {
            return false;
        }
    }

    @Override
    public boolean $greater$eq( CategorySortKey2 that) {
        if(this.$greater(that)){
            return true;
        }else if(this.clickCount == that.getClickCount() && this.orderCount == that.getOrderCount() && this.payCount == that.getPayCount()){
            return true;
        }else {
            return false;
        }
    }

    @Override
    public int compareTo( CategorySortKey2 that) {
        if(this.clickCount - that.getClickCount() != 0){
            return (int)(this.clickCount - that.getClickCount());
        }else if(this.orderCount - that.getOrderCount() != 0){
            return (int)(this.orderCount - that.getOrderCount());
        }else if(this.payCount - that.getPayCount() != 0){
            return (int)(this.payCount - that.getPayCount());
        }else{
            return 0;
        }
    }
}
