package dao;


import domain.SessionRandomExtract;

/**
 * session聚合统计模块接口
 */
public interface SessionExtractRandomDAO {
    /**
     * 插入session随机抽取
     * @param sessionRandomExtract
     */
    void insert(SessionRandomExtract sessionRandomExtract);
}
