package dao;


import domain.SessionDetail;

/**
 * session明细DAO接口
 */
public interface SessionDetailDAO {
    /**
     * 插入一条session明细数据
     * @param sessionDetail
     */
    void insert(SessionDetail sessionDetail);
}
