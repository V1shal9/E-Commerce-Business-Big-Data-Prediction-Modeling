package dao;


import domain.Top10Category;

/**
 * top10品类DAO接口
 */



public interface Top10CategoryDAO {
    void insert(Top10Category top10Category);
}
