package dao;


import domain.SessionAggrStat;

/**
 * session聚合统计模块接口
 */
public interface SessionAggrDAO {
    /**
     * 插入session聚合统计结果
     * @param sessionAggrStat
     */
    void insert(SessionAggrStat sessionAggrStat);
}
