package domain;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class top10Test {
    public static void main(String[] args) throws Exception{
        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("D:\\test.txt")));
        String line = null;

        String[] top10Sessions = new String[10];
        while((line = br.readLine()) != null){
            Long count = Long.valueOf(line.split(",")[1]);
            for(int i=0;i<top10Sessions.length;i++){
                if(top10Sessions[i] == null){
                    top10Sessions[i] = line;
                    break;
                }else{
                    long _count = Long.valueOf(top10Sessions[i].split(",")[1]);
                    if(count > _count){
                        for(int j=9;j>i;j--){
                            top10Sessions[j] = top10Sessions[j-1];
                        }
                        top10Sessions[i] = line;
                        break;
                    }
                }
            }
        }

        for(String session:top10Sessions){
            System.out.println(session);
        }


    }
}
