package impl;


import dao.Top10CategoryDAO;
import domain.Top10Category;
import jdbc.JDBCHelper;

public class Top10CategoryDAOImpl implements Top10CategoryDAO {
    @Override
    public void insert(Top10Category top10Category) {
        String sql = "insert into top10_category values(?,?,?,?,?)";
        Object[] params = new Object[]{top10Category.getTaskId(),top10Category.getCategoryId(),
        top10Category.getClickCount(),top10Category.getOrderCount(),top10Category.getPayCount()};

        JDBCHelper jdbcHelper = JDBCHelper.getInstance();
        jdbcHelper.executeUpdate(sql, params);
    }
}
