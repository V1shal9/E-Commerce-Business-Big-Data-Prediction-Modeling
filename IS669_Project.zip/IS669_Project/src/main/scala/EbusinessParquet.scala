import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

object EbusinessParquet {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("ebusiness").master("local[4]").getOrCreate()
    val sc = spark.sparkContext

    val textFile = sc.textFile("D:\\logs\\input\\ebusiness\\ebusiness-.1571349339908")


    val rowRDD = textFile.filter(log => {
      log.length > 0 && log.split(",").length == 15
    }).map(log => {
      val fields = log.split(",")
      val row = Row(fields(0), fields(1).toLong, fields(2), fields(3).toLong, fields(4), fields(5), fields(6).toLong,
        fields(7).toLong, fields(8), fields(9), fields(10), fields(11), fields(12).toLong, fields(13).toDouble, fields(14).toLong)
      row

    })


    val schema = StructType(Array(
      StructField("day", StringType, true),
      StructField("user_id", LongType, true),
      StructField("session_id", StringType, true),
      StructField("page_id", LongType, true),
      StructField("action_time", StringType, true),
      StructField("search_keyword", StringType, true),
      StructField("click_category_id", LongType, true),
      StructField("click_product_id", LongType, true),
      StructField("order_category_ids", StringType, true),
      StructField("order_product_ids", StringType, true),
      StructField("pay_category_ids", StringType, true),
      StructField("pay_product_ids", StringType, true),
      StructField("product_id", LongType, true),
      StructField("rate", DoubleType, true),
      StructField("city_id", LongType, true)
    ))

    val df: DataFrame = spark.createDataFrame(rowRDD,schema)
    df.write.parquet("D:\\logs\\input\\ebusiness2")
  }
}
