import org.apache.spark.sql.SparkSession

object Connection {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("Connection").master("local[*]").getOrCreate()

    spark.read.csv("")

  }
}
