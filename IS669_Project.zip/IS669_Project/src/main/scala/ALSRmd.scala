
import org.apache.spark.mllib.evaluation.RegressionMetrics
import org.apache.spark.mllib.recommendation.{ALS, Rating}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

object ALSRmd {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("ALSRmd").master("local[4]").getOrCreate()
    val sc = spark.sparkContext
    sc.setLogLevel("WARN")

    println(sc.version)
    println("========================")
    val userLog = sc.textFile("D:\\logs\\input\\ebusiness\\ebusiness.log")
    val ratingRDD: RDD[Rating] = userLog.filter(log => {
      log.length > 0 &log.split(",").length == 15
    }).map(log => {

      val userId = log.split(",")(1).toInt
      val productId = log.split(",")(12).toInt

      val rate = log.split(",")(13).toDouble

      Rating(userId, productId,rate)
    })

    // Split data into traning data and test data
    val Array(traingRDD,testRDD) = ratingRDD.randomSplit(Array(0.8,0.2))

    val alsModel = ALS.train(traingRDD,10,10,0.1)


    // recommand 10 products for userId 26
    val rating: Array[Rating] = alsModel.recommendProducts(26,10)
    rating.foreach(println)

    val testFeature: RDD[((Int, Int), Double)] = testRDD.map(r => {
      ((r.user, r.product), r.rating)
    })
    val predictRDD: RDD[((Int, Int), Double)] = alsModel.predict(testFeature.map(_._1)).map(r => {
      ((r.user,r.product),r.rating)
    })

    val predictionAndActual: RDD[(Double, Double)] = predictRDD.join(testFeature).map(_._2)

    val alsMetrics = new RegressionMetrics(predictionAndActual)

    println(alsMetrics.rootMeanSquaredError)


    spark.stop()
  }
}
