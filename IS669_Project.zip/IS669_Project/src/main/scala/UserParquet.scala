import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

object UserParquet {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("ebusiness2").master("local[4]").getOrCreate()
    val sc = spark.sparkContext

    val textFile = sc.textFile("D:\\logs\\input\\ebusiness\\user.log")


    val rowRDD = textFile.filter(log => {
      log.length > 0 && log.split(",").length == 7
    }).map(log => {
      val fields = log.split(",")
      val row = Row(fields(0).toLong, fields(1), fields(2), fields(3).toInt, fields(4), fields(5), fields(6))
      row
    })


    val schema = StructType(Array(
      StructField("user_id", LongType, true),
      StructField("user_name", StringType, true),
      StructField("name", StringType, true),
      StructField("age", IntegerType, true),
      StructField("professional", StringType, true),
      StructField("city", StringType, true),
      StructField("sex", StringType, true)
    ))

    val df: DataFrame = spark.createDataFrame(rowRDD,schema)
    df.write.parquet("D:\\logs\\input\\user_info")
  }
}
