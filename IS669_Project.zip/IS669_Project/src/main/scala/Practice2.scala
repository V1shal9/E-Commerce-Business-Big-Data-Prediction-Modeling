
import java.util.Properties

import org.apache.spark.mllib.fpm.FPGrowth
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

object Practice2 {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("practice").master("local[4]").getOrCreate()
    val sc = spark.sparkContext
    val productCSV = spark.read.option("header",true).option("schema",true).csv("D:\\logs\\input\\2019-Nov.csv")
    val sqlContext = spark.sqlContext

    val productIdFilterRDD= productCSV.rdd.filter(row => {
      row.getString(3) != null && row.getString(7) != null && row.getString(6) != null
    })
    val productIdActionRDD : RDD[(String, Row)] = productIdFilterRDD.map(row => {
      (row.getString(3),row)
    })
    println("productIdActionRDD:"+productIdActionRDD.count())

    val url = "jdbc:mysql://localhost:3306/spark_project"
    val prop = new Properties()

    val productInfoCSV = spark.read.option("head",true).csv("D:\\logs\\input\\product_info.csv")
    // TODO. First Part
    /**
      * product Count
      */
    val productInfoRDD = productInfoCSV.rdd.map(row => {
      (row.getString(0), row.getString(1))
    })

    val productInfoMapBroadcast = sc.broadcast(productInfoRDD.collectAsMap())


    val productAndOne = productInfoRDD.join(productIdActionRDD).map(tp => {
      (tp._2._1,1)
    })

    val productNumCountRDD: RDD[Row] = productAndOne.reduceByKey(_+_).map(tp => {
      val productName: String = tp._1
      val productNum: Int = tp._2

      Row(productName,productNum)
    }).sortBy(_.getString(0))


    prop.setProperty("driver","com.mysql.jdbc.Driver")
    prop.put("user","root")
    prop.put("password","123456")


    val schema = StructType(Array(
      StructField("product_name",StringType,true),
      StructField("product_count",IntegerType,true)
    ))

    val productNumCountActionRDD: DataFrame = sqlContext.createDataFrame(productNumCountRDD,schema)
    productNumCountActionRDD.write.mode("overwrite").jdbc(url,"product_count_table_copy",prop)


    /**
      * city_count
      */
    val cityInfoCSV = spark.read.option("header",true).csv("D:\\logs\\input\\city_info.csv")
    cityInfoCSV.show(5,false)
    val cityInfoMap: collection.Map[String, String] = cityInfoCSV.rdd.map(row => {
      val cityId = row.getString(0)
      val cityName = row.getString(1)
      println(cityName)
      (cityId, cityName)
    }).collectAsMap()
    val cityInfoMapBroadcast = sc.broadcast(cityInfoMap)

    val cityIdAndNumActionRDD: RDD[Row] = productIdActionRDD.map(tp => {
      val cityInfoMap = cityInfoMapBroadcast.value
      val cityName = cityInfoMap(tp._2.getString(8))
      (cityName, 1)
    }).reduceByKey(_ + _).map(tp => {
      Row(tp._1,tp._2)
    }).sortBy(_.getString(0))

    val citySchema = StructType(
      Array(
        StructField("city_name", StringType, true),
        StructField("city_count", IntegerType, true)
      )
    )
    sqlContext.createDataFrame(cityIdAndNumActionRDD,citySchema)
      .write.mode("overwrite").jdbc(url,"city_count_table_copy",prop)

    // println(cityIdAndNumActionRDD.collect().toBuffer)

    /**
      * brand_count
      */
    val brandCountActionRDD = productIdActionRDD.filter(_._2.getString(4) != null).map(tp => {
      val brand = tp._2.getString(4)
      (brand, 1)
    }).reduceByKey(_ + _).map(tp => {
      Row(tp._1,tp._2)
    }).sortBy(_.getString(0))

    val brandSchema = StructType(Array(
      StructField("brand_name", StringType, true),
      StructField("brand_count", IntegerType, true)
    ))

    sqlContext.createDataFrame(brandCountActionRDD,brandSchema)
      .write.mode("overwrite").jdbc(url,"brand_count_table_copy_copy",prop)

    // println(brandCountActionRDD.collect().toBuffer)

    //time_count
    val timeActionRDD = productIdActionRDD.map(tp => {
      val time = tp._2.getString(0).split(" ")(1).substring(0, 2)
      (time, 1)
    }).reduceByKey(_+_).map(tp => {
      Row(tp._1,tp._2)
    }).sortBy(_.getString(0))

    val timeSchema = StructType(
      Array(
        StructField("time", StringType, true),
        StructField("count", IntegerType, true)
      )
    )

    sqlContext.createDataFrame(timeActionRDD,timeSchema)
      .write.mode("overwrite").jdbc(url,"time_count_table_copy",prop)

    val userId2categoryNameRDD: RDD[(String, String)] = productIdFilterRDD.map(row => {
      val userId = row.getString(6)
      (userId, row)
    }).groupByKey().map(tp => {
      val iterator = tp._2.toIterator
      val categoryIdBuffer = new StringBuffer()
      var userId = ""
      val productInfoMap = productInfoMapBroadcast.value

      while (iterator.hasNext) {

        val row = iterator.next()
        if (userId.equals("")) {
          userId = row.getString(6)
        }
        val categoryId = row.getString(3)
        val categoryName = productInfoMap(categoryId)

        if(!categoryIdBuffer.toString.contains(categoryName)){
          categoryIdBuffer.append(categoryName + ",")
        }

      }
      var purchasedCategoryName = categoryIdBuffer.toString()
      purchasedCategoryName = purchasedCategoryName.substring(0,purchasedCategoryName.length() - 1)
      (userId,purchasedCategoryName)
    })

    val userId2categoryName = userId2categoryNameRDD.map(tp => {
      val userid = tp._1
      val purchasedProduct = tp._2.substring(0, tp._2.length() - 1)
      Row(userid, purchasedProduct)
    })

    prop.setProperty("driver","com.mysql.jdbc.Driver")
    prop.put("user","root")
    prop.put("password","123456")


    val purchasedCategoryName = StructType(
      Array(
        StructField("user_id", StringType, true),
        StructField("purchased_category_name", StringType, true)
      )
    )
    sqlContext.createDataFrame(userId2categoryName,purchasedCategoryName)
      .write.mode("overwrite").jdbc(url,"purchased_category_table_copy",prop)


    val productRDD: RDD[Array[String]] = userId2categoryNameRDD.filter(tp => {
      tp._2.split(",").length > 1
    }).map(tp => {
      tp._2.split(",")
    })


    val fpgrowth = new FPGrowth().setMinSupport(0.08).setNumPartitions(4).run(productRDD)
    val rulesRDD = fpgrowth.generateAssociationRules(0.2)

    val relationRDD: RDD[Row] = rulesRDD.map(rule => {
      val antecedent = rule.antecedent.mkString(",")
      val consequence = rule.consequent.mkString(",")
      val confidence = rule.confidence

      Row(antecedent, consequence, confidence)
    })

    val relationSchema = StructType(Array(
      StructField("antecedent",StringType,true),
      StructField("consequent",StringType,true),
      StructField("confidence",DoubleType,true)
    ))


    prop.setProperty("driver","com.mysql.jdbc.Driver")
    prop.put("user","root")
    prop.put("password","123456")

    spark.createDataFrame(relationRDD,relationSchema).registerTempTable("tmp_relation_table")
    val sql = "SELECT * FROM tmp_relation_table ORDER BY confidence DESC"

    sqlContext.sql(sql).write.mode("overwrite").jdbc(url,"product_relation_table_copy",prop)
    spark.stop()

  }
}
