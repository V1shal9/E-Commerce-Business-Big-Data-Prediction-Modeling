import org.apache.hadoop.io.NullWritable
import org.apache.hadoop.mapred.lib.MultipleTextOutputFormat
import org.apache.spark.sql.SparkSession

object SplitData {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("practice").master("local[4]").getOrCreate()
    val sc = spark.sparkContext
    val productCSV = spark.read.option("header",true).option("schema",true).csv("D:\\logs\\input\\2019-Oct.csv")
    val sqlContext = spark.sqlContext

    import spark.implicits._
    val data = productCSV.map(row => {
      val event_time = row.getString(0)
      val event_type = row.getString(1)
      val product_id = row.getString(2)
      val category_id = row.getString(3)
      val brand = row.getString(4)
      val price = row.getString(5)
      val user_id = row.getString(6)
      val user_session = row.getString(7)
      val city_id = row.getString(8)
      val value = "," + event_type + "," + product_id + "," + category_id + "," + brand + "," + price + "," +
        user_id + "," + user_session + "," + city_id
      (event_time, value)
    })

    data.rdd.saveAsHadoopFile("D:\\logs\\input\\out",classOf[String],classOf[String],classOf[RDDMultipleClassPath])

    spark.stop()

  }
}

class RDDMultipleClassPath extends MultipleTextOutputFormat[Any,Any]{

  override def generateFileNameForKeyValue(key: Any, value: Any, name: String): String = {
    val fields = key.toString.split(" ")
    val day = fields(0)

    val path = day + ".txt";
    path
  }

}