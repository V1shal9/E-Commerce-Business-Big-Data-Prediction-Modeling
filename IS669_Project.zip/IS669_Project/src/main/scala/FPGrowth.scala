
import org.apache.spark.mllib.fpm.{AssociationRules, FPGrowth, FPGrowthModel}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DoubleType, StringType, StructField, StructType}
import org.apache.spark.sql.{Row, RowFactory, SparkSession}


object FPGrowth {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("FPGrowth").master("local[4]").getOrCreate()
    val sc = spark.sparkContext
    sc.setLogLevel("WARN")


    val textFile = sc.textFile("D:\\logs\\input\\ebusiness\\ebusiness2.log").filter(line => {
      line.length > 0 && line.split(",").length == 15
    })

    val ebusinessRDD: RDD[Array[String]] = textFile.map(line => {
      val userId = line.split(",")(1)
      val searchKeyword = line.split(",")(5)
      (userId, searchKeyword)
    }).distinct().groupByKey().map(tp => {
      tp._2.toArray
    })

    val fpGrowth: FPGrowth = new FPGrowth().setMinSupport(0.2).setNumPartitions(4)
    val fpGrowthModel: FPGrowthModel[String] = fpGrowth.run(ebusinessRDD)

    val freqItemsRDD = fpGrowthModel.freqItemsets
//    freqItemsRDD.filter(freqItem => {
//      freqItem.items.length >= 2 && freqItem.items.length <= 4
//    }).collect().foreach(println)

    val rulesRDD: RDD[AssociationRules.Rule[String]] = fpGrowthModel.generateAssociationRules(0.8)
    val rmdItemsRDD: RDD[(String, (String, Double))] = rulesRDD.map(rule => {
      (rule.antecedent.mkString(","), (rule.consequent.mkString(","), rule.confidence))
    })

    val outputRDD: RDD[String] = rmdItemsRDD.map(tp => {
      tp._1 + ":" + tp._2._1 + ":" + tp._2._2
    })

    //outputRDD.coalesce(1).saveAsTextFile("D:\\logs\\input\\ebusiness\\out")

    //rmdItemsRDD.coalesce(1).saveAsTextFile("D:\\logs\\input\\ebusiness\\ebusiness3.log")

    val rowRDD: RDD[Row] = rmdItemsRDD.filter(tp => {
      tp._1.split(",").length <= 2
    }).map(ruleTp => {
      val itemAntecedent = ruleTp._1
      val itemConsequence = ruleTp._2._1
      val confidence = ruleTp._2._2

      Row(itemAntecedent,itemConsequence,confidence)
    })

    val schema = StructType(Array(
      StructField("itemAntecedent", StringType, true),
      StructField("itemConsequence", StringType, true),
      StructField("confidence", DoubleType, true)
    ))

    val itemDF = spark.createDataFrame(rowRDD,schema)
//    itemDF.show()

    itemDF.createTempView("v_item")
    val sql = "SELECT * FROM v_item ORDER BY confidence ASC";
    spark.sql(sql).show(50,truncate = true)

    Thread.sleep(10000)
    spark.stop()
  }
}
